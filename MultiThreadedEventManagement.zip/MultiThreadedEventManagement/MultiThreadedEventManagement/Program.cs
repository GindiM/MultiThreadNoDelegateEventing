﻿using System;

public class IntWrap
{
    public IntWrap() //ctor
    {
        this.integer = 0;
    }
    public IntWrap(IntWrap toBeCopied) //copy ctor
    {
        integer = toBeCopied.integer;
    }

    public int integer { get; set; }


    static public IntWrap[] CopyArrayOfIntWraps(params IntWrap[] IntWrapArrayToBeCopied)
    {
        IntWrap[] IntWrapArrayCopy = new IntWrap[IntWrapArrayToBeCopied.Length];

        for (int i = 0; i < IntWrapArrayToBeCopied.Length; i++)
        {
            IntWrapArrayCopy[i] = new IntWrap(IntWrapArrayToBeCopied[i]);
        }
        return IntWrapArrayCopy;
    }
}
public class Program
{

    public static IntWrap num1 = new IntWrap();
    public static IntWrap num2 = new IntWrap();
    public static IntWrap num3 = new IntWrap();

    //public static int num1;
    //public static int num2;
    //public static int num3;

    public static void Main()
    {
        Thread intScanner = new Thread(() => { PrintInts(500,num1, num2, num3); });
        intScanner.Start();

        while (true)
        {
            try
            {
                num3.integer = Int32.Parse(Console.ReadLine());
            }
            catch { }
        }
    }


    public static void PrintInts(int interval_ms, params IntWrap[] nums)
    {
        IntWrap[] previousNums = IntWrap.CopyArrayOfIntWraps(nums);

        while (true)
        {
            for (int i = 0; i < nums.Length; i++)
            {
                Console.WriteLine($"{i}: {nums[i].integer}");
                if (nums[i].integer != previousNums[i].integer)
                {
                    Console.WriteLine($"number {previousNums[i].integer} was changed to {nums[i].integer}");
                }

            }

            previousNums = IntWrap.CopyArrayOfIntWraps(nums);

            Thread.Sleep(interval_ms);
        }
    }
}
